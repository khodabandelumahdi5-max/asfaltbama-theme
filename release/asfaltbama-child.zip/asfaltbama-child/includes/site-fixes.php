<?php
/**
 * Site-wide fixes found in the SEO audit: head clean-up, the business
 * plugin's footer links, internal links without a trailing slash, avatar
 * alt text, empty image placeholders and article links on service pages.
 *
 * @package AsfaltbamaChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
 * Head clean-up: the RSD, Windows Live Writer and shortlink tags and the
 * comments feed serve no visitor, and the emoji script is ~20 KB of
 * render-blocking JavaScript that every current browser can do without.
 */
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
add_filter( 'feed_links_show_comments_feed', '__return_false' );

/**
 * Service links for the footer: [label, path].
 *
 * @return array[]
 */
function asfaltbama_footer_service_links() {
	return array_values(
		array_filter(
			asfaltbama_service_links(),
			function ( $link ) {
				return ! in_array( $link[1], [ '/asphalt-price-per-ton/', '/service-areas/', '/industrial-asphalt-waterproofing/' ], true );
			}
		)
	);
}

/**
 * Fix the footer printed by the Asphalt Business Suite plugin:
 * - the phone lines and the «تماس سریع» button link to "#";
 * - «مقالات» points at /asphalt-cost-per-square-meter/ instead of /articles/;
 * - the services are plain text, so they pass no link value.
 *
 * @param string $html Footer HTML.
 *
 * @return string
 */
function asfaltbama_fix_business_footer( $html ) {
	$tel = 'tel:' . ASFALTBAMA_PHONE;

	// Company email instead of the personal address set in the plugin.
	$html = str_replace( 'khodabandelumahdi9@gmail.com', 'ofoghapadanapasargad@gmail.com', $html );

	$html = str_replace(
		[
			'<a href="#">☎',
			'<a href="#">📱',
			'<a class="aas-btn aas-btn-primary" href="#">',
		],
		[
			'<a href="tel:02177344068">☎',
			'<a href="' . $tel . '">📱',
			'<a class="aas-btn aas-btn-primary" href="' . $tel . '">',
		],
		$html
	);

	$html = preg_replace(
		'#href="[^"]*/asphalt-cost-per-square-meter/?"(\s*)>(\s*)مقالات#u',
		'href="' . esc_url( asfaltbama_articles_url() ) . '"$1>$2مقالات',
		$html
	);

	// «مناطق تحت پوشش» after «مقالات» in the quick links.
	$html = preg_replace(
		'#(<a href="[^"]*/articles/"\s*>\s*مقالات\s*</a>)#u',
		'$1' . "\n" . '<a href="' . esc_url( home_url( '/services/' ) ) . '">همه‌ی خدمات</a>'
			. "\n" . '<a href="' . esc_url( home_url( '/service-areas/' ) ) . '">مناطق تحت پوشش</a>'
			. "\n" . '<a href="' . esc_url( home_url( '/industrial-asphalt-waterproofing/' ) ) . '">آسفالت و عایق کارخانه‌ها</a>'
			. "\n" . '<a href="' . esc_url( home_url( '/asphalt-contractor-middle-east/' ) ) . '" lang="en" dir="ltr">English</a>'
			. "\n" . '<a href="' . esc_url( home_url( '/asphalt-contractor-middle-east-ar/' ) ) . '" lang="ar">العربية</a>',
		$html,
		1
	);

	$links = '';
	foreach ( asfaltbama_footer_service_links() as $link ) {
		$links .= '<span><a href="' . esc_url( home_url( $link[1] ) ) . '">' . esc_html( $link[0] ) . '</a></span>';
	}

	return preg_replace(
		'#(<div class="aas-footer-card[^"]*aas-footer-services">\s*<h3>[^<]*</h3>\s*<div>).*?(</div>)#su',
		'$1' . $links . '$2',
		$html,
		1
	);
}

/**
 * Rewrite the finished page: trailing slashes on root-relative internal
 * links (the header menu links /asphalt-paving, which answers with a 301)
 * and the business plugin's footer.
 *
 * @param string $html Page HTML.
 *
 * @return string
 */
function asfaltbama_filter_page_html( $html ) {
	if ( false === stripos( $html, '<html' ) ) {
		return $html;
	}

	$html = preg_replace( '#href="(/[a-z0-9\-/]*[a-z0-9\-])"#', 'href="$1/"', $html );

	$start = strpos( $html, '<footer class="aas-site-footer"' );
	if ( false !== $start ) {
		$end = strpos( $html, '</footer>', $start );
		if ( false !== $end ) {
			$footer = substr( $html, $start, $end - $start );
			$html   = substr_replace( $html, asfaltbama_fix_business_footer( $footer ), $start, $end - $start );
		}
	}

	$html = asfaltbama_mobile_nav( $html );
	$html = asfaltbama_fix_heading_order( $html );
	$html = asfaltbama_fix_inline_service_schema( $html );

	if ( function_exists( 'asfaltbama_wire_quote_form' ) ) {
		$html = asfaltbama_wire_quote_form( $html );
	}

	if ( function_exists( 'asfaltbama_perf_html' ) ) {
		$html = asfaltbama_perf_html( $html );
	}

	return $html;
}

/**
 * Buffer front-end HTML pages for asfaltbama_filter_page_html().
 *
 * @return void
 */
function asfaltbama_start_page_buffer() {
	if ( is_admin() || is_feed() || is_embed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || is_customize_preview() ) {
		return;
	}
	if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	ob_start( 'asfaltbama_filter_page_html' );
}
add_action( 'template_redirect', 'asfaltbama_start_page_buffer', 99 );

/**
 * Give author avatars an alt text (WordPress prints alt='').
 *
 * @param array $args Avatar arguments.
 *
 * @return array
 */
function asfaltbama_avatar_alt( $args ) {
	if ( empty( $args['alt'] ) ) {
		$post        = get_post();
		$args['alt'] = 'تصویر نویسنده: ' . ( $post ? asfaltbama_author_name( $post ) : 'آسفالت با ما' );
	}
	return $args;
}
add_filter( 'pre_get_avatar_data', 'asfaltbama_avatar_alt' );

/**
 * Drop Elementor image widgets that only show the grey placeholder (e.g. a
 * loop item whose post has no featured image).
 *
 * @param string                 $content Widget HTML.
 * @param \Elementor\Widget_Base $widget  Widget.
 *
 * @return string
 */
function asfaltbama_hide_placeholder_images( $content, $widget ) {
	if ( 'image' === $widget->get_name() && false !== strpos( $content, 'elementor/assets/images/placeholder.png' ) ) {
		return '';
	}
	return $content;
}
add_filter( 'elementor/widget/render_content', 'asfaltbama_hide_placeholder_images', 10, 2 );

/**
 * Article categories related to each service page.
 *
 * @return array Page slug => category slugs.
 */
function asfaltbama_service_categories() {
	return apply_filters(
		'asfaltbama_service_categories',
		[
			'asphalt-paving'         => [ 'asphalt-paving', 'cost-estimation' ],
			'excavation-and-grading' => [ 'excavation-grading', 'machinery-rental' ],
			'demolition-scrap'       => [ 'demolition', 'cost-estimation' ],
			'isogam-waterproofing'   => [ 'waterproofing-isogam', 'bitumen' ],
			'asphalt-joint-sealing'  => [ 'joint-sealing', 'asphalt-paving' ],
			'machinery-rental'       => [ 'machinery-rental', 'excavation-grading' ],
		]
	);
}

/**
 * Append three related articles to service pages. They linked to no
 * article at all, so the guides that support each service got no link
 * value and visitors had no path to them.
 *
 * @param string $content Page content.
 *
 * @return string
 */
function asfaltbama_service_related_articles( $content ) {
	static $done = false;

	if ( $done || ! is_page() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$map  = asfaltbama_service_categories();
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	if ( ! isset( $map[ $slug ] ) ) {
		return $content;
	}

	$ids = [];
	foreach ( $map[ $slug ] as $cat_slug ) {
		$term = get_category_by_slug( $cat_slug );
		if ( $term ) {
			$ids[] = $term->term_id;
		}
	}
	if ( ! $ids ) {
		return $content;
	}

	$posts = get_posts(
		[
			'numberposts'  => 3,
			'category__in' => $ids,
		]
	);
	if ( ! $posts ) {
		return $content;
	}

	$done     = true;
	$services = asfaltbama_service_pages();
	$label    = isset( $services[ $slug ] ) ? $services[ $slug ][1] : get_the_title();
	$main_cat = get_category_by_slug( $map[ $slug ][0] );

	$html  = '<section class="abm-latest abm-service-articles" aria-labelledby="abm-service-articles-title"><div class="abm-wrap">';
	$html .= '<h2 id="abm-service-articles-title" class="abm-section-title">' . esc_html( 'راهنماهای ' . $label ) . '</h2>';
	$html .= '<div class="abm-grid">';
	foreach ( $posts as $post ) {
		$html .= asfaltbama_post_card( $post, 'h3' );
	}
	$html .= '</div><p class="abm-latest__links">';
	if ( $main_cat ) {
		$html .= '<a class="abm-btn abm-btn--dark" href="' . esc_url( get_category_link( $main_cat ) ) . '">' . esc_html( 'همه‌ی مقالات ' . $main_cat->name ) . '</a>';
	}
	$html .= '<a class="abm-btn abm-btn--amber" href="tel:' . esc_attr( ASFALTBAMA_PHONE ) . '">مشاوره‌ی رایگان: <span dir="ltr">' . esc_html( ASFALTBAMA_PHONE_DISPLAY ) . '</span></a>';
	$html .= '</p>' . asfaltbama_area_links() . '</div></section>';

	return $content . $html;
}
add_filter( 'the_content', 'asfaltbama_service_related_articles', 30 );

/**
 * Area pages from the manifest (pages with area_served), except the hub.
 *
 * @return array[] Page manifest items.
 */
function asfaltbama_area_pages() {
	$pages = [];
	foreach ( (array) ( asfaltbama_content_manifest()['pages'] ?? [] ) as $item ) {
		if ( ! empty( $item['area_served'] ) && 'service-areas' !== $item['slug'] && 'fa' === ( $item['lang'] ?? 'fa' ) ) {
			$pages[] = $item;
		}
	}
	return $pages;
}

/**
 * Links to the area pages, for the service pages.
 *
 * @return string
 */
function asfaltbama_area_links() {
	$items = '';
	foreach ( asfaltbama_area_pages() as $item ) {
		$items .= '<a href="' . esc_url( home_url( '/' . $item['slug'] . '/' ) ) . '">' . esc_html( implode( ' و ', $item['area_served'] ) ) . '</a>';
	}
	if ( ! $items ) {
		return '';
	}
	return '<nav class="abm-areas" aria-label="مناطق تحت پوشش"><span class="abm-areas__title">مناطق تحت پوشش:</span>' . $items . '<a href="' . esc_url( home_url( '/service-areas/' ) ) . '">همه‌ی مناطق</a></nav>';
}

/**
 * Service entity for the area pages: what is offered and where.
 *
 * @param array $data Schema entities.
 *
 * @return array
 */
function asfaltbama_area_schema( $data ) {
	if ( ! is_array( $data ) || ! is_page() ) {
		return $data;
	}
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	foreach ( (array) ( asfaltbama_content_manifest()['pages'] ?? [] ) as $item ) {
		if ( $item['slug'] !== $slug || empty( $item['area_served'] ) ) {
			continue;
		}
		$url   = get_permalink( get_queried_object_id() );
		$areas = [];
		foreach ( (array) $item['area_served'] as $area ) {
			$areas[] = [
				'@type' => 'Place',
				'name'  => $area,
			];
		}
		$data['asfaltbamaAreaService'] = [
			'@type'       => 'Service',
			'@id'         => $url . '#service',
			'name'        => get_the_title( get_queried_object_id() ),
			'serviceType' => [
				'fa' => 'آسفالت‌کاری، خاکبرداری و عایق‌کاری',
				'en' => 'Asphalt paving and waterproofing',
				'ar' => 'رصف الأسفلت والعزل المائي',
			][ $item['lang'] ?? 'fa' ] ?? 'آسفالت‌کاری، خاکبرداری و عایق‌کاری',
			'description' => $item['seo_description'] ?? '',
			'url'         => $url,
			'provider'    => [ '@id' => home_url( '/#organization' ) ],
			'areaServed'  => $areas,
		];
		break;
	}
	return $data;
}
add_filter( 'rank_math/json_ld', 'asfaltbama_area_schema', 20 );

/**
 * Project photo gallery on a service page (manifest service_galleries),
 * placed before the related articles. Real project photos show visitors
 * and search engines first-hand work, not stock images.
 *
 * @param string $content Page content.
 *
 * @return string
 */
function asfaltbama_service_gallery( $content ) {
	static $done = false;

	if ( $done || ! is_page() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$galleries = (array) ( asfaltbama_content_manifest()['service_galleries'] ?? [] );
	$slug      = get_post_field( 'post_name', get_queried_object_id() );
	if ( empty( $galleries[ $slug ]['images'] ) ) {
		return $content;
	}
	$gallery = $galleries[ $slug ];

	$items = '';
	foreach ( (array) $gallery['images'] as $source ) {
		$id = asfaltbama_imported_media_id( $source );
		if ( ! $id ) {
			continue;
		}
		$caption = wp_get_attachment_caption( $id ) ?: get_the_title( $id );
		$items  .= '<figure class="abm-gallery__item">';
		$items  .= wp_get_attachment_image(
			$id,
			'medium_large',
			false,
			[
				'loading' => 'lazy',
				'sizes'   => '(max-width: 600px) 50vw, 300px',
			]
		);
		$items  .= '<figcaption>' . esc_html( $caption ) . '</figcaption></figure>';
	}
	if ( ! $items ) {
		return $content;
	}

	$done  = true;
	$html  = '<section class="abm-latest abm-gallery" aria-labelledby="abm-gallery-title"><div class="abm-wrap">';
	$html .= '<h2 id="abm-gallery-title" class="abm-section-title">' . esc_html( $gallery['title'] ) . '</h2>';
	if ( ! empty( $gallery['intro'] ) ) {
		$html .= '<p class="abm-gallery__intro">' . esc_html( $gallery['intro'] ) . '</p>';
	}
	$html .= '<div class="abm-gallery__grid">' . $items . '</div></div></section>';

	return $content . $html;
}
add_filter( 'the_content', 'asfaltbama_service_gallery', 29 );

/**
 * Tag archives: noindex, follow and out of the sitemap. Each tag lists
 * only a few articles that the category pages already list, so indexing
 * them would add thin, near-duplicate pages. The tags still link related
 * articles for visitors.
 *
 * @param array $robots Robots values.
 *
 * @return array
 */
function asfaltbama_tag_robots( $robots ) {
	if ( is_tag() ) {
		$robots['index']  = 'noindex';
		$robots['follow'] = 'follow';
	}
	return $robots;
}
add_filter( 'rank_math/frontend/robots', 'asfaltbama_tag_robots' );

/**
 * Keep tag archives out of Rank Math's sitemap.
 *
 * @param bool   $exclude  Whether to exclude.
 * @param string $taxonomy Taxonomy.
 *
 * @return bool
 */
function asfaltbama_tag_sitemap( $exclude, $taxonomy ) {
	return 'post_tag' === $taxonomy ? true : $exclude;
}
add_filter( 'rank_math/sitemap/exclude_taxonomy', 'asfaltbama_tag_sitemap', 10, 2 );

/**
 * Whether the current page is written in the editor rather than built with
 * Elementor (area pages, the services page).
 *
 * @return bool
 */
function asfaltbama_is_plain_page() {
	return is_page() && ! is_front_page()
		&& 'builder' !== get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true );
}

/**
 * Body class for plain pages, for the page title styles.
 *
 * @param string[] $classes Body classes.
 *
 * @return string[]
 */
function asfaltbama_plain_page_class( $classes ) {
	if ( asfaltbama_is_plain_page() ) {
		$classes[] = 'abm-plain-page';
	}
	return $classes;
}
add_filter( 'body_class', 'asfaltbama_plain_page_class' );

/**
 * Give plain pages the article typography and a call-to-action box.
 *
 * @param string $content Page content.
 *
 * @return string
 */
function asfaltbama_plain_page_wrap( $content ) {
	if ( ! asfaltbama_is_plain_page() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	$lang = asfaltbama_page_lang();
	if ( function_exists( 'asfaltbama_is_intl_article' ) && asfaltbama_is_intl_article() ) {
		// article-intl.php and guides-intl.php lay these pages out.
		return $content;
	}
	if ( function_exists( 'asfaltbama_is_article_hub' ) && asfaltbama_is_article_hub() ) {
		return $content;
	}
	if ( asfaltbama_is_landing() ) {
		// Landing pages bring their own full-width layout and contact band.
		$dir = 'en' === $lang ? 'ltr' : 'rtl';
		return '<div class="abm-lp" lang="' . esc_attr( $lang ) . '" dir="' . $dir . '">' . $content . '</div>';
	}
	if ( 'fa' !== $lang ) {
		// English / Arabic pages carry their own email and WhatsApp box.
		$dir = 'ar' === $lang ? 'rtl' : 'ltr';
		return '<div class="abm-page abm-prose" lang="' . esc_attr( $lang ) . '" dir="' . $dir . '">' . $content . '</div>';
	}
	return '<div class="abm-page abm-prose">' . $content . asfaltbama_cta( 'box' ) . '</div>';
}
add_filter( 'the_content', 'asfaltbama_plain_page_wrap', 40 );

/**
 * Manifest item of the current page, if the theme created it.
 *
 * @return array|null
 */
function asfaltbama_current_manifest_page() {
	static $item = false;
	if ( false === $item ) {
		$item = null;
		if ( is_page() ) {
			$slug = get_post_field( 'post_name', get_queried_object_id() );
			foreach ( (array) ( asfaltbama_content_manifest()['pages'] ?? [] ) as $page ) {
				if ( $page['slug'] === $slug ) {
					$item = $page;
					break;
				}
			}
		}
	}
	return $item;
}

/**
 * Language of the current page: fa, or en / ar for the international pages.
 *
 * @return string
 */
function asfaltbama_page_lang() {
	$item = asfaltbama_current_manifest_page();
	return $item['lang'] ?? 'fa';
}

/**
 * English and Arabic pages: <html lang>, og:locale and schema inLanguage.
 *
 * @param string $locale Locale.
 *
 * @return string
 */
function asfaltbama_intl_locale( $locale ) {
	$map = [
		'en' => 'en_US',
		'ar' => 'ar',
	];
	return $map[ asfaltbama_page_lang() ] ?? $locale;
}
add_filter( 'asfaltbama_content_locale', 'asfaltbama_intl_locale' );

/**
 * og:locale needs a region: ar -> ar_AR.
 *
 * @param string $locale Locale.
 *
 * @return string
 */
function asfaltbama_intl_og_locale( $locale ) {
	return 'ar' === $locale ? 'ar_AR' : $locale;
}
add_filter( 'rank_math/opengraph/facebook/og_locale', 'asfaltbama_intl_og_locale', 20 );

/**
 * hreflang links between the language versions of a page (manifest
 * hreflang_group), with the English page as x-default.
 *
 * @return void
 */
function asfaltbama_hreflang_links() {
	$group = '';
	if ( is_singular( 'post' ) ) {
		// Persian articles with English and Arabic versions.
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		foreach ( (array) ( asfaltbama_content_manifest()['posts'] ?? [] ) as $post ) {
			if ( $post['slug'] === $slug ) {
				$group = $post['hreflang_group'] ?? '';
				break;
			}
		}
	} else {
		$item  = asfaltbama_current_manifest_page();
		$group = $item['hreflang_group'] ?? '';
	}
	if ( '' === $group ) {
		return;
	}
	$tags = [
		'fa' => 'fa-IR',
		'en' => 'en',
		'ar' => 'ar',
	];
	$manifest = asfaltbama_content_manifest();
	$links    = [];
	foreach ( (array) ( $manifest['posts'] ?? [] ) as $post ) {
		if ( ( $post['hreflang_group'] ?? '' ) === $group ) {
			$links['fa'] = home_url( '/' . $post['slug'] . '/' );
		}
	}
	foreach ( (array) ( $manifest['pages'] ?? [] ) as $page ) {
		if ( ( $page['hreflang_group'] ?? '' ) === $group ) {
			$links[ $page['lang'] ?? 'fa' ] = home_url( '/' . $page['slug'] . '/' );
		}
	}
	if ( count( $links ) < 2 ) {
		return;
	}
	foreach ( $links as $lang => $url ) {
		printf( '<link rel="alternate" hreflang="%s" href="%s" />' . "\n", esc_attr( $tags[ $lang ] ?? $lang ), esc_url( $url ) );
	}
	$default = $links['en'] ?? reset( $links );
	printf( '<link rel="alternate" hreflang="x-default" href="%s" />' . "\n", esc_url( $default ) );
}
add_action( 'wp_head', 'asfaltbama_hreflang_links', 5 );

/**
 * Body class with the page language, for direction-aware styles.
 *
 * @param string[] $classes Body classes.
 *
 * @return string[]
 */
function asfaltbama_lang_body_class( $classes ) {
	if ( 'fa' !== asfaltbama_page_lang() ) {
		$classes[] = 'abm-lang-' . asfaltbama_page_lang();
	}
	return $classes;
}
add_filter( 'body_class', 'asfaltbama_lang_body_class' );

/**
 * [abm_gallery files="a.jpg|b.jpg" captions="…|…" lang="en"]: project
 * photos imported from content/images, with captions in the page language
 * (also used as the alt text).
 *
 * @param array $atts Attributes.
 *
 * @return string
 */
function asfaltbama_gallery_shortcode( $atts ) {
	$atts     = shortcode_atts(
		[
			'files'    => '',
			'captions' => '',
			'lang'     => 'fa',
		],
		$atts
	);
	$files    = array_filter( array_map( 'trim', explode( '|', $atts['files'] ) ) );
	$captions = array_map( 'trim', explode( '|', $atts['captions'] ) );

	$items = '';
	foreach ( array_values( $files ) as $i => $file ) {
		$id = asfaltbama_imported_media_id( $file );
		if ( ! $id ) {
			continue;
		}
		$caption = $captions[ $i ] ?? '';
		$items  .= '<figure class="abm-gallery__item">';
		$items  .= wp_get_attachment_image(
			$id,
			'medium_large',
			false,
			[
				'loading' => 'lazy',
				'alt'     => $caption ? $caption : get_post_meta( $id, '_wp_attachment_image_alt', true ),
				'sizes'   => '(max-width: 600px) 50vw, 280px',
			]
		);
		if ( $caption ) {
			$items .= '<figcaption>' . esc_html( $caption ) . '</figcaption>';
		}
		$items .= '</figure>';
	}

	return $items ? '<div class="abm-gallery__grid abm-gallery__grid--inline">' . $items . '</div>' : '';
}
add_shortcode( 'abm_gallery', 'asfaltbama_gallery_shortcode' );

/**
 * Author links point to the about page: author archives are off (the link
 * answered with a redirect) and /author/<login>/ exposed the login name.
 *
 * @return string
 */
function asfaltbama_author_link() {
	return home_url( '/about-us/' );
}
add_filter( 'author_link', 'asfaltbama_author_link' );

/**
 * Article schema: the author Person carried the login name ("admin").
 * Name the editorial team instead and point it to the about page.
 *
 * @param array $data Schema entities.
 *
 * @return array
 */
function asfaltbama_author_schema( $data ) {
	if ( ! is_array( $data ) || ! is_singular( 'post' ) ) {
		return $data;
	}
	$post  = get_post();
	$login = $post ? get_the_author_meta( 'user_login', $post->post_author ) : '';
	$name  = asfaltbama_author_name( $post );
	foreach ( $data as $key => $entity ) {
		if ( ! is_array( $entity ) || 'Person' !== ( $entity['@type'] ?? '' ) ) {
			continue;
		}
		if ( ( $entity['name'] ?? '' ) === $login || ( $entity['name'] ?? '' ) === 'admin' ) {
			$data[ $key ]['name'] = $name;
			$data[ $key ]['url']  = home_url( '/about-us/' );
			unset( $data[ $key ]['image'], $data[ $key ]['sameAs'] );
		}
	}
	// Other entities may repeat the author's name inline.
	array_walk_recursive(
		$data,
		function ( &$value, $k ) use ( $login, $name ) {
			if ( 'name' === $k && ( $value === $login || 'admin' === $value ) ) {
				$value = $name;
			}
		}
	);
	return $data;
}
add_filter( 'rank_math/json_ld', 'asfaltbama_author_schema', 99 );

/**
 * Bylines: show the editorial team instead of the login name ("admin")
 * that the article template prints.
 *
 * @param string $name Author display name.
 *
 * @return string
 */
function asfaltbama_byline_name( $name ) {
	if ( is_admin() || wp_doing_ajax() || ( ! in_the_loop() && ! is_singular( 'post' ) ) ) {
		return $name;
	}
	$post = get_post();
	return $post ? asfaltbama_author_name( $post ) : $name;
}
add_filter( 'the_author', 'asfaltbama_byline_name' );
add_filter( 'get_the_author_display_name', 'asfaltbama_byline_name' );

/**
 * Article dates in the Persian calendar with Persian digits, wherever the
 * site's default date format is used on the front end. Machine formats
 * (c, U, Y-m-d …) used by feeds and schema are left alone.
 *
 * @param string       $the_date Formatted date.
 * @param string       $format   Requested format ('' = site default).
 * @param WP_Post|null $post     Post.
 *
 * @return string
 */
function asfaltbama_jalali_the_date( $the_date, $format, $post ) {
	if ( is_admin() || is_feed() || wp_doing_ajax() || ( '' !== $format && get_option( 'date_format' ) !== $format ) ) {
		return $the_date;
	}
	$post = get_post( $post );
	return $post ? asfaltbama_date( $post->post_date ) : $the_date;
}
add_filter( 'get_the_date', 'asfaltbama_jalali_the_date', 10, 3 );

/**
 * Mobile menu for the header (Elementor HTML widget, .abm-hdr-*).
 *
 * The widget hides its menu below 900px and has no menu button, so on
 * phones there was no way to reach the services, articles, about or
 * contact pages. Add a menu button, call/WhatsApp buttons inside the menu,
 * and a small script that opens and closes it (styles in style.css). Also
 * point «توزیع قیر و مصالح عایق» at the bitumen page; it repeated the
 * isogam link.
 *
 * @param string $html Page HTML.
 * @return string
 */
function asfaltbama_mobile_nav( $html ) {
	if ( false === strpos( $html, '<ul class="abm-nav-menu">' ) ) {
		return $html;
	}

	$html = str_replace( '<a href="/isogam-waterproofing/">📦', '<a href="/bitumen-price/">📦', $html );

	$button = '<button type="button" class="abm-menu-toggle" aria-controls="abm-nav-menu" aria-expanded="false" aria-label="منوی سایت">'
		. '<span></span><span></span><span></span></button>';
	$html   = preg_replace( '#<ul class="abm-nav-menu">#', $button . '<ul class="abm-nav-menu" id="abm-nav-menu">', $html, 1 );

	$cta  = '<li class="abm-nav-item abm-nav-cta">'
		. '<a class="abm-nav-cta__call" href="tel:' . esc_attr( ASFALTBAMA_PHONE ) . '">📞 تماس: <span dir="ltr">' . esc_html( ASFALTBAMA_PHONE_DISPLAY ) . '</span></a>'
		. '<a class="abm-nav-cta__wa" href="' . esc_url( ASFALTBAMA_WHATSAPP ) . '" target="_blank" rel="noopener">💬 مشاوره در واتساپ</a>'
		. '</li>';
	$html = preg_replace( '#(<ul class="abm-nav-menu" id="abm-nav-menu">.*?)(</ul>)#s', '$1' . $cta . '$2', $html, 1 );

	$script = '<script id="abm-mobile-nav">(function(){var b=document.querySelector(".abm-menu-toggle"),m=document.getElementById("abm-nav-menu"),h=b&&b.closest(".abm-hdr-wrap");if(!b||!m||!h)return;'
		. 'function s(o){h.classList.toggle("is-menu-open",o);b.setAttribute("aria-expanded",o?"true":"false");if(o){h.style.setProperty("--abm-menu-top",Math.max(h.getBoundingClientRect().bottom,0)+"px")}}'
		. 'b.addEventListener("click",function(e){e.stopPropagation();s(!h.classList.contains("is-menu-open"))});'
		. 'm.addEventListener("click",function(e){if(e.target.closest("a"))s(false)});'
		. 'document.addEventListener("click",function(e){if(!h.contains(e.target))s(false)});'
		. 'document.addEventListener("keydown",function(e){if(e.key==="Escape")s(false)});'
		. 'window.addEventListener("resize",function(){if(window.innerWidth>900)s(false)});'
		. 'window.addEventListener("scroll",function(){if(h.classList.contains("is-menu-open"))h.style.setProperty("--abm-menu-top",Math.max(h.getBoundingClientRect().bottom,0)+"px")},{passive:true});})();</script>';

	$pos = strripos( $html, '</body>' );
	return false === $pos ? $html : substr_replace( $html, $script, $pos, 0 );
}

/**
 * Heading order on pages built in Elementor: the service pages jump from
 * h2 to h4 (feature boxes) and the contact page from h1 to h3. Search
 * engines and screen readers read headings as an outline, so a skipped
 * level is reported as an error. Each heading that skips a level is
 * raised to the next level (h4 → h3) and keeps its look: it gets the
 * class abm-hN, and the page's own CSS rules for hN also match it.
 *
 * @param string $html Page HTML.
 * @return string
 */
function asfaltbama_fix_heading_order( $html ) {
	if ( ! is_page() ) {
		return $html;
	}
	$start = strpos( $html, '<body' );
	if ( false === $start ) {
		return $html;
	}
	$prev    = 0;
	$changed = [];
	$body    = preg_replace_callback(
		'#<h([1-6])(\s[^>]*)?>(.*?)</h\1>#s',
		static function ( $m ) use ( &$prev, &$changed ) {
			$level = (int) $m[1];
			if ( $prev && $level > $prev + 1 ) {
				$new   = $prev + 1;
				$attrs = isset( $m[2] ) ? $m[2] : '';
				if ( preg_match( '/\sclass="([^"]*)"/', $attrs ) ) {
					$attrs = preg_replace( '/\sclass="([^"]*)"/', ' class="$1 abm-h' . $level . '"', $attrs, 1 );
				} else {
					$attrs .= ' class="abm-h' . $level . '"';
				}
				$changed[ $level ] = true;
				// Following siblings of the same original level end up
				// at the same new level, because $prev stays one above.
				$prev = $new - 1;
				return '<h' . $new . $attrs . '>' . $m[3] . '</h' . $new . '>';
			}
			$prev = $level;
			return $m[0];
		},
		substr( $html, $start )
	);
	if ( ! $changed || null === $body ) {
		return $html;
	}
	$html = substr( $html, 0, $start ) . $body;
	// Let the page's CSS rules for the old tag style the raised heading too:
	// «.box h4 {…}» → «.box :is(h4,.abm-h4) {…}». Only selectors are touched.
	return preg_replace_callback(
		'#<style\b[^>]*>(.*?)</style>#s',
		static function ( $m ) use ( $changed ) {
			$css = preg_replace_callback(
				'/([^{}]+)\{/',
				static function ( $r ) use ( $changed ) {
					$sel = $r[1];
					foreach ( array_keys( $changed ) as $lv ) {
						$sel = preg_replace( '/(?<![\w\-.#:])h' . $lv . '(?![\w\-])/', ':is(h' . $lv . ',.abm-h' . $lv . ')', $sel );
					}
					return $sel . '{';
				},
				$m[1]
			);
			return str_replace( $m[1], $css, $m[0] );
		},
		$html
	);
}

/**
 * Schema written by hand in the Elementor service pages:
 * - an AggregateOffer with no price (lowPrice is required, so Search
 *   Console reports it invalid) is dropped;
 * - the Service provider, a nameless LocalBusiness, points at the site's
 *   organization entity, which carries the full business details;
 * - a page with two HTML widgets had two FAQPage and two Service entities
 *   (Search Console: «Duplicate field FAQPage»): the questions are merged
 *   into the first FAQPage and the later duplicates are removed.
 *
 * @param string $html Page HTML.
 * @return string
 */
function asfaltbama_fix_inline_service_schema( $html ) {
	if ( ! preg_match_all( '#<script type="application/ld\+json"[^>]*>(.*?)</script>#s', $html, $all, PREG_OFFSET_CAPTURE ) ) {
		return $html;
	}
	$blocks = [];
	foreach ( $all[1] as $i => $match ) {
		if ( false !== strpos( $all[0][ $i ][0], 'rank-math' ) ) {
			continue;
		}
		$data = json_decode( $match[0], true );
		if ( is_array( $data ) && ( false !== strpos( $match[0], '"Service"' ) || false !== strpos( $match[0], '"FAQPage"' ) ) ) {
			$blocks[ $i ] = $data;
		}
	}
	if ( ! $blocks ) {
		return $html;
	}

	$fix = static function ( $node ) use ( &$fix ) {
		if ( ! is_array( $node ) ) {
			return $node;
		}
		if ( isset( $node['offers']['@type'] ) && 'AggregateOffer' === $node['offers']['@type'] && empty( $node['offers']['lowPrice'] ) ) {
			unset( $node['offers'] );
		}
		if ( isset( $node['@type'] ) && 'Service' === $node['@type'] && isset( $node['provider']['@type'] ) && empty( $node['provider']['@id'] ) ) {
			$node['provider'] = [ '@id' => home_url( '/#organization' ) ];
		}
		foreach ( $node as $k => $v ) {
			if ( is_array( $v ) ) {
				$node[ $k ] = $fix( $v );
			}
		}
		return $node;
	};

	// Merge FAQPage and Service entities across the blocks.
	$faq     = null; // [block index, entity index or null for a top-level entity].
	$service = false;
	foreach ( $blocks as $i => $data ) {
		$data  = $fix( $data );
		$graph = isset( $data['@graph'] ) && is_array( $data['@graph'] ) ? $data['@graph'] : [ $data ];
		foreach ( $graph as $j => $entity ) {
			$type = $entity['@type'] ?? '';
			if ( 'FAQPage' === $type ) {
				if ( null === $faq ) {
					$faq = [ $i, $j ];
				} else {
					$first = &$blocks[ $faq[0] ];
					$target = isset( $first['@graph'] ) ? $first['@graph'][ $faq[1] ] : $first;
					$target['mainEntity'] = array_merge( (array) ( $target['mainEntity'] ?? [] ), (array) ( $entity['mainEntity'] ?? [] ) );
					if ( isset( $first['@graph'] ) ) {
						$first['@graph'][ $faq[1] ] = $target;
					} else {
						$first = $target;
					}
					unset( $first );
					unset( $graph[ $j ] );
				}
			} elseif ( 'Service' === $type ) {
				if ( $service ) {
					unset( $graph[ $j ] );
				}
				$service = true;
			}
		}
		if ( isset( $data['@graph'] ) ) {
			$data['@graph'] = array_values( $graph );
			$blocks[ $i ]   = $data;
		} else {
			$blocks[ $i ] = $graph ? $data : null;
		}
	}

	// Write back from the end, so earlier offsets stay valid.
	foreach ( array_reverse( array_keys( $all[0] ) ) as $i ) {
		if ( ! array_key_exists( $i, $blocks ) ) {
			continue;
		}
		$data = $blocks[ $i ];
		$tag  = $all[0][ $i ];
		$out  = ( null === $data || ( isset( $data['@graph'] ) && ! $data['@graph'] ) )
			? ''
			: '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
		$html = substr_replace( $html, $out, $tag[1], strlen( $tag[0] ) );
	}
	return $html;
}

/**
 * Rank Math adds an Article rich snippet to every page. On landing,
 * service, area and contact pages that is the wrong type (they are not
 * articles), and on the English and Arabic guides it duplicates the
 * BlogPosting entity this theme adds. Keep it on posts only.
 *
 * @param array $data Schema entities.
 * @return array
 */
function asfaltbama_page_drop_article_schema( $data ) {
	if ( ! is_array( $data ) || ! is_page() ) {
		return $data;
	}
	foreach ( $data as $key => $entity ) {
		$id = is_array( $entity ) && isset( $entity['@id'] ) && is_string( $entity['@id'] ) ? $entity['@id'] : '';
		if ( 'richSnippet' !== $key && '#richSnippet' !== substr( $id, -12 ) ) {
			continue;
		}
		if ( array_intersect( (array) ( $entity['@type'] ?? [] ), [ 'Article', 'BlogPosting', 'NewsArticle' ] ) ) {
			unset( $data[ $key ] );
		}
	}
	return $data;
}
add_filter( 'rank_math/json_ld', 'asfaltbama_page_drop_article_schema', 98 );
